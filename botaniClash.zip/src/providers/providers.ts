import { DynamoDB } from './aws.dynamodb';

export {
  DynamoDB
};
