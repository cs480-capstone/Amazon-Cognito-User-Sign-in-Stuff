import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { TreeFactory } from '../providers/treefactory';
import { BotaniMap } from '../pages/map/map';
import { Geolocation } from '@ionic-native/geolocation';
import { HttpModule } from '@angular/http';
import { SignupPageModule } from '../pages/signup/signup.module';
import { ConfirmSignUpPageModule } from '../pages/confirmSignUp/confirmSignUp.module';
import { ConfirmSignInPageModule } from '../pages/confirmSignIn/confirmSignIn.module'
import { LoginPageModule } from '../pages/login/login.module'
import { AccountPageModule } from '../pages/account/account.module';
import { ConfirmPageModule } from '../pages/confirm/confirm.module';
import { TabsPageModule } from '../pages/tabs/tabs.module';
import { DynamoDB } from '../providers/aws.dynamodb';
import { MenuPageModule } from '../pages/menu/menu.module';
import { PersonalForestModule } from '../pages/personalForest/forest.module';
import { DataCollectionModule } from '../pages/dataCollection/dataCollection.module';
import { DivisionalLeaderboardModule } from '../pages/divisionalLeaderboard/divisionalLeaderboard.module';
import { EntryPasserProvider } from '../providers/entry-passer/entry-passer';
import { DataCollection } from '../pages/dataCollection/dataCollection';

import Amplify from 'aws-amplify';
const aws_exports = require('../aws-exports').default;

import { MyApp } from './app.component';

import { BotaniMapModule } from '../pages/map/map.module';

Amplify.configure(aws_exports);

@NgModule({
  declarations: [
    MyApp,
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    SignupPageModule,
    ConfirmSignUpPageModule,
    ConfirmSignInPageModule,
    LoginPageModule,
    AccountPageModule,
    ConfirmPageModule,
    TabsPageModule,
    BotaniMapModule,
    MenuPageModule,
    PersonalForestModule,
    DataCollectionModule,
    DivisionalLeaderboardModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    DataCollection,
    BotaniMap
  ],
  providers: [
    Geolocation,
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    TreeFactory,
    HttpModule,
    EntryPasserProvider
  ]
})
export class AppModule {}

declare var AWS;
AWS.config.customUserAgent = AWS.config.customerUserAgent + ' Ionic';
